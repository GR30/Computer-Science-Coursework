import Foundation
//Import different libraries for different OS's
#if os(Linux)
    import Glibc
#else
    import Darwin
#endif

//Protocol for the cardBox class
protocol cardBoxPro {
    var cardHold:[Card] {get set};
    
    func addCard(card:Card);            //Adds cards to the card box
    func removeCard() -> Card;          //Removes cards from the card box
    func cardAmt() -> Int;              //Returns the number of cards in the box
    func shuffle();                     //Shuffles the cards
}

//CardBox Class. It contains discarded cards that have been used. It is used to suffle the cards as well.
class cardBox:cardBoxPro{
    var cardHold = [Card]();
    
    func addCard(card:Card){ cardHold.append(card); }
    func removeCard() -> Card { return cardHold.removeFirst(); }
    func cardAmt() -> Int { return cardHold.count; }
    func shuffle(){
        for _ in 0...cardHold.count{
            
            #if os(Linux)
                var randint = Int(random() % cardHold.count);
                var randint2 = Int(random() % cardHold.count);
                
                var temp = cardHold[randint];
                
                cardHold[randint] = cardHold[randint2];
                cardHold[randint2] = temp;
            #else
                let randint1 = Int(arc4random_uniform(UInt32(cardHold.count)));
                let randint2 = Int(arc4random_uniform(UInt32(cardHold.count)));
                
                let temp = cardHold[randint1];
                
                cardHold[randint1] = cardHold[randint2];
                cardHold[randint2] = temp;
            #endif
            
            
            
            
        }
    }
}

class GreenCardBox: cardBox{
    static var cardHold = [Card]();
    
    static func addCard(card:Card){ cardHold.append(card); }
    static func removeCard() -> Card { return cardHold.removeFirst(); }
    static func cardAmt() -> Int { return cardHold.count; }
    static func shuffle(){
        for _ in 0...cardHold.count{
            
            #if os(Linux)
                var randint = Int(random() % cardHold.count);
                var randint2 = Int(random() % cardHold.count);
                
                var temp = cardHold[randint];
                
                cardHold[randint] = cardHold[randint2];
                cardHold[randint2] = temp;
            #else
                let randint1 = Int(arc4random_uniform(UInt32(cardHold.count)));
                let randint2 = Int(arc4random_uniform(UInt32(cardHold.count)));
                
                let temp = cardHold[randint1];
                
                cardHold[randint1] = cardHold[randint2];
                cardHold[randint2] = temp;
            #endif
            
            
            
            
        }
    }

}

class RedCardBox: cardBox{
    static var cardHold = [Card]();
    
    static func addCard(card:Card){ cardHold.append(card); }
    static func removeCard() -> Card { return cardHold.remove(at: 0); }
    static func cardAmt() -> Int { return cardHold.count; }
    static func shuffle(){
        for _ in 0...cardHold.count{
            
            #if os(Linux)
                var randint = Int(random() % cardHold.count);
                var randint2 = Int(random() % cardHold.count);
                
                var temp = cardHold[randint];
                
                cardHold[randint] = cardHold[randint2];
                cardHold[randint2] = temp;
            #else
                let randint1 = Int(arc4random_uniform(UInt32(cardHold.count)));
                let randint2 = Int(arc4random_uniform(UInt32(cardHold.count)));
                
                let temp = cardHold[randint1];
                
                cardHold[randint1] = cardHold[randint2];
                cardHold[randint2] = temp;
            #endif
            
            
            
            
        }
    }

}
