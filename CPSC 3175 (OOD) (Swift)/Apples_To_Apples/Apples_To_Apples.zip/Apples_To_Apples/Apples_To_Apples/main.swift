import Foundation;

//Protocol for the game class.
protocol GamePro{
    
    var table:[Card] {get set};
    var players:[Player] {get set};
    var redApples:[Card] {get set};
    var greenApples:[Card] {get set};
    var playerAmt:Int {get set};
    var winCon:Int {get set};
    var handSize:Int {get set};
    var rounds:Int {get set};
    var winner:Int? {get set};
    
    func makeApples();                          //Imports texts from text files to make the cards.
    func chooseFromTable(i:Int) -> Int;         //For the judge to pick the best matching card from the table.
    func dealHands();                           //Gives the players the specified amount of cards
    func dealCard(cardType:String) -> Card;     //Draws a card from the specified deck
    func emptyDeckCheck();                      //Checks if the decks are empty
    func newJudge(i:Int);                       //Switches the judge to a new player
    func gameOver() -> Bool;                    //Checks to see if the win condition has been met
    func displayTable();                        //Displays the cards on the table
    func displayScores();                       //Displays the score board
    func main();                                //Contians the main logic of the game
}

//Game class. It contains the logic to make the game work. Includes a main function.
class Game: GamePro{
    var table = [Card]();
    var players = [Player]();
    var redApples = [Card]();
    var greenApples = [Card]();
    var redBox:cardBox!;
    var greenBox:cardBox!;
    var playerAmt:Int;
    var winCon:Int;
    var handSize:Int;
    var rounds:Int;
    var winner:Int?;
    
    init (playerAmt:Int, handSize:Int, winCon:Int){
        for _ in 1...playerAmt{ players.append( Player(hS:handSize) ); }
        self.playerAmt = playerAmt;
        self.handSize = handSize;
        self.winCon = winCon;
        rounds = 1;
    }
    
    func makeApples(){
        
        var path = "/Users/djseldon/Desktop/Apples_To_Apples/Apples_To_Apples/redTexts.txt";
            do {
                let data = try String(contentsOfFile: path, encoding: .utf8);
                let myStrings = data.components(separatedBy: .newlines);
                
                for myString in myStrings{
                    let words = myString.components(separatedBy: " [");
                    RedCardBox.addCard(card: Card(text: words[0]));
                }
                
                
                RedCardBox.shuffle();
                
                
                
                for _ in 0..<RedCardBox.cardAmt(){
                    redApples.append(RedCardBox.removeCard());
                }
            }
            
            catch let error as NSError{
                print("Failed reading from URL: \(path), Error: " + error.localizedDescription + " " + error.localizedFailureReason!);
                print("Try typing in the file path");
                path = readLine()!;
                do {
                    let data = try String(contentsOfFile: path, encoding: .utf8);
                    let myStrings = data.components(separatedBy: .newlines);
                    
                    for myString in myStrings{
                        let words = myString.components(separatedBy: " [");
                        RedCardBox.addCard(card: Card(text: words[0]));
                    }
                    
                    
                    RedCardBox.shuffle();
                    
                    
                    
                    for _ in 0..<RedCardBox.cardAmt(){
                        redApples.append(RedCardBox.removeCard());
                    }
                }
                    
                catch let error as NSError{
                    print("Failed reading from URL: \(path), Error: " + error.localizedDescription + " " + error.localizedFailureReason!);
                
            }
        }
        
        
        
        path = "/Users/djseldon/Desktop/Apples_To_Apples/Apples_To_Apples/greenTexts.txt";
            do {
                let data = try String(contentsOfFile: path, encoding: .utf8);
                let myStrings = data.components(separatedBy: .newlines);
                
                for myString in myStrings{
                    let words = myString.components(separatedBy: " [");
                    GreenCardBox.addCard(card: Card(text: words[0]));
                }
                
                GreenCardBox.shuffle();
                
                for _ in 0..<GreenCardBox.cardAmt(){
                    greenApples.append(GreenCardBox.removeCard());
                }
        
            }
                
            catch let error as NSError{
                print("Failed reading from URL: \(path), Error: " + error.localizedDescription + " " + error.localizedFailureReason!);
                
                print("Try typing in the file path");
                path = readLine()!;
                do {
                    let data = try String(contentsOfFile: path, encoding: .utf8);
                    let myStrings = data.components(separatedBy: .newlines);
                    
                    for myString in myStrings{
                        let words = myString.components(separatedBy: " [");
                        GreenCardBox.addCard(card: Card(text: words[0]));
                    }
                    
                    GreenCardBox.shuffle();
                    
                    for _ in 0..<GreenCardBox.cardAmt(){
                        greenApples.append(GreenCardBox.removeCard());
                    }
                    
                }
                    
                catch let error as NSError{
                    print("Failed reading from URL: \(path), Error: " + error.localizedDescription + " " + error.localizedFailureReason!);
                }
        }
        
    }
    
    func chooseFromTable(i:Int) -> Int{
        return table[i].getOwner().getPlayerNum();
    }
    
    func dealHands(){
        for p in players{
            if(!p.getIsJudge()){
                for _ in 1...handSize{
                    p.drawNewCard(card:dealCard(cardType:"red"));
                }
            }
            
            else{
                for _ in 2...handSize{
                    p.drawNewCard(card:dealCard(cardType:"red"));
                }
            }
        }
    }
    
    func dealCard(cardType:String) -> Card{
        emptyDeckCheck();
        var dealtCard:Card;
        
        if (cardType == "green"){
            dealtCard = greenApples.removeFirst();
        }
        else {
            dealtCard = redApples.removeFirst();
        }
        
        return dealtCard;
    }
    
    func emptyDeckCheck(){
        if (redApples.isEmpty == true){
            for _ in 1...redBox.cardAmt(){
                redApples.append(redBox.removeCard());
            }
        }
        
        if (greenApples.isEmpty == true){
            for _ in 1...greenBox.cardAmt(){
                greenApples.append(greenBox.removeCard());
            }
        }
    }
    
    func newJudge(i:Int){
        for p in players{
            if (p.getIsJudge()){
                p.setIsJudge(state: false);
            }
        }
        players[i].setIsJudge(state: true)
    }
    
    func gameOver() -> Bool{
        var win:Bool = false;
        for p in players{
            if (p.getRoundsWon() == winCon){
                win = true;
                winner = p.getPlayerNum();
            }
        }
        return win;
    }
    
    func displayTable(){
        var ret = "Green Apple: " + table[0].getText() + "\nRed Apples: ";
        for x in 1...table.count-1{
            ret += table[x].getText();
            if (x != table.count-1){
                ret += ",";
            }
        }
        print(ret);
    }
    
    func displayScores(){
        var ret = "CURRENT SCORES\n";
        for x in players{
            ret += "Player " + String(describing:x.getPlayerNum());
            ret += " Score: " + String(describing:x.getRoundsWon()) + "\n";
        }
        print(ret);
    }
    
    func main(){
        print("Making Apples... \n\n");
        makeApples();
        players[0].setIsJudge(state:true);
        
        for p in 1...players.count{
            players[p-1].setPlayerNum(pNum:p);
        }
        
        dealHands();
    
        repeat{
            if (rounds != 1){
                for p in players{ 
                    if (!p.isJudge){
                        p.drawNewCard(card:dealCard(cardType:"red"));
                    }
                }
            }
         
            table.append(greenApples.removeFirst());
            
            for p in players{
                if (!p.getIsJudge()){
                    print("Player: \(p.getPlayerNum())\n");
                    print("Green Card: " + table[0].getText());
                    table.append(p.chooseCard());
                }
            }
            
            print("Judge, choose the card that best fits your card.");
            displayTable();
            var select = Int(readLine()!)!;
            while(select>=table.count){
                print("Invalid input");
                select = Int(readLine()!)!;
            }
            
            
            
            let winnerOfRound = chooseFromTable(i: select);
            
            players[winnerOfRound].winRound();
            print("Round Winner: Player " + String(winnerOfRound+1));
            
            
            
            GreenCardBox.addCard(card: table.removeFirst());
            GreenCardBox.shuffle();
            
            for _ in 0...table.count-1{
                RedCardBox.addCard(card: table.removeFirst());
            }
            
            
            print("Next Round\n");
            displayScores();
            rounds+=1;
            newJudge(i:winnerOfRound);
        }
        while(!gameOver())
        print("WINNER! PLAYER " + String(describing: winner) + "!");
    }
}

print("Welcome to Apples to Apples! Here are the rules:");
print("1. Player #1 is the judge. There is a green card pulled from the deck and will be shown. \n2. Players (except the judge) quickly choose the red apple card from their hand that is best described by the word on the green apple card played by the judge. \n3. At the end of the round the judge selects the one he or she thinks is best described by the word on the green apple card. The player of the selected red apple card is awarded the green apple card played by the judge. \n4. To keep score, players keep the green apple cards they have won, on the table, until the end of the game. \n5. Play continues following steps 1-4 until someone has earned enough green apple cards to win the game!");

print("How many players are there? Must be more then 2.");
var players = Int((readLine())!)!;
while(players<3){
    print("Must be more then 2.");
    players = Int((readLine())!)!
}

print("How many cards will the players get? Must be more than 3.");
var size = Int((readLine())!)!;
while(size<4){
    print("Must be more than 3.");
    size = Int((readLine())!)!;
}

print("How many green cards will a player need to win?");
var cond = Int((readLine())!)!;

let newGame = Game(playerAmt:players, handSize:size, winCon:cond);
newGame.main();
print("PROGRAM END");
