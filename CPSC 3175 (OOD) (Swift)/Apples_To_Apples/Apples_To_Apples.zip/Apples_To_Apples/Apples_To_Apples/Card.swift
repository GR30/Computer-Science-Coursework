import Foundation

//Protocol for the Card class
protocol CardPro {
    var text:String {get set};
    var next:Card? {get set};
    var owner:Player? {get set};
    
    func getText() -> String;           //Returns the text from the card
    func setOwner(owner:Player);        //Sets thee owner of the card
    func getOwner() -> Player;          //Returns the owner of the card
}

//Card class. It contains all of the componets to make card objects.
class Card:CardPro{

    var text:String;
    var next:Card?;
    var owner:Player?;
    
    init(text:String){
        self.text = text;
    }
    
    func getText() -> String{
        return "[" + text + "]";
    }
    
    func setOwner(owner:Player){ self.owner = owner; }
    func getOwner() -> Player{ return owner!; }
}
