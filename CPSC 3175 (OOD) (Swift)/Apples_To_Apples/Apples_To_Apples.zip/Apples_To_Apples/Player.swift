import Foundation

//Protocol for the Player class
protocol PlayerPro{
    var hand:[Card] {get set};
    var isJudge:Bool {get set};
    var roundsWon:Int {get set};
    var playerNum:Int {get set};
    var nextPlayer:Player? {get set};
    var handSize:Int {get set};
    
    func winRound();                            //Adds a point to the player's score
    func getRoundsWon() -> Int;                 //Returns how many rounds the player won
    func setPlayerNum(pNum:Int);                //Sets the player's ID number
    func getPlayerNum() -> Int;                 //Returns the player's ID number
    func setIsJudge(state:Bool);                //Sets the player to be a judge
    func getIsJudge() -> Bool;                  //Returns whether or not the player is a judge
    func drawNewCard(card:Card);                //Adds a card to the player's hand
    func chooseCard() -> Card;                  //Player picks card to be used
    func displayHand();                         //Displays the player's hand
}

class Player: PlayerPro{
    
    var hand = [Card]();
    var isJudge:Bool;
    var roundsWon:Int;
    var playerNum:Int;
    var nextPlayer:Player?;
    var handSize:Int;
    
    init(hS:Int){
        isJudge = false;
        playerNum = 0;
        roundsWon = 0;
        handSize = hS
        
    }
    
    func winRound(){ roundsWon+=1; }
    func getRoundsWon() -> Int { return roundsWon; }
    
    func setPlayerNum(pNum:Int){ playerNum = pNum; }
    func getPlayerNum() -> Int { return playerNum; }
    
    func setIsJudge(state:Bool){ isJudge = state; }
    func getIsJudge() -> Bool { return isJudge; }
    
    func drawNewCard(card:Card){
        let addition = card;
        addition.setOwner(owner: self);
        hand.append(addition);
    }
    
    func chooseCard() -> Card{
        if (isJudge) {
            hand.removeLast()
        }
        displayHand();
        print("Choose a card.");
        var choice = Int(readLine()!)!;
        choice -= 1;
        while(choice>=hand.count){
            print("Invalid input!");
            choice = Int(readLine()!)!;
            choice -= 1
        }
        let chosen:Card = hand[choice];
        hand.remove(at: choice)
        return chosen;
    }
    
    func displayHand(){
        for i in hand{
            print(i.getText());
        }
        
    }
}

