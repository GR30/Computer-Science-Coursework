//: Playground - noun: a place where people can play

class Card{
    var id:String = "";
    
    init(id:String){
        self.id = id;
    }
    
    func getId() -> String{
        return id;
    }
    
    func setId(id:String){
        self.id = id;
    }
}

class PropertyCard:Card{
    var propertyName:String;
    var rent:Int;
    var rentOneHouse:Int;
    var rentTwoHouse:Int;
    var rentThreeHouse:Int;
    var rentFourHouse:Int;
    
    init(propertyName:String, rent:Int, rentOneHouse:Int, rentTwoHouse:Int, rentThreeHouse:Int, rentFourHouse:Int){
        self.propertyName = propertyName;
        self.rent = rent;
        self.rentOneHouse = rentOneHouse;
        self.rentTwoHouse = rentTwoHouse;
        self.rentThreeHouse = rentThreeHouse;
        self.rentFourHouse = rentFourHouse;
        super.init(id: propertyName);
    }
    
    func getPropertyName() -> String{
        return propertyName;
    }
    
    //Add accessors and mutators
    
}

class Currency{
    var value:Int;
    var denomination:String;
    
    init(value:Int, denomination:String){
        self.denomination = denomination;
        self.value = value;
    }
    
    func getValue() -> Int{
        return value;
    }
    
    func getDenomination() -> String {
        return denomination;
    }
}

class StackOfCurrency{
    var stackCurrency = [Currency]();
    
    init(){
        
    }
    
    init(currency:Currency){
        stackCurrency.append(currency);
    }
    
    init(stackCurrency:[Currency]){
        self.stackCurrency = stackCurrency;
    }
    
    func getTotalAmount() -> Int{
        var total = 0;
        
        for item in stackCurrency{
            total += item.getValue();
        }
        
        return total;
    }
    
    
    func getCurrency(denomination:String) -> Currency{
            return stackCurrency.removeFirst()
    }
    
    func addCurrency(currency:Currency){
        stackCurrency.append(currency)
    }
    
    func addStackCurrenct(sc:[Currency]){
        stackCurrency.append(contentsOf: sc);
    }
}




class Bank{
    var propertyCards = [String:PropertyCard]();
    var trayOfCurrency = [Int:StackOfCurrency]();
    
    var trayOfMoney:[Int:StackOfCurrency] = [1:StackOfCurrency(), 5:StackOfCurrency()]
    
    func getTotalAmount() -> Int{
        //var total = trayOfCurrency[1]!.getTotalAmount() + trayOfCurrency[5]!.getTotalAmount();
        var total = 0;
        
        for (_, value) in trayOfMoney {
            //total += trayOfMoney[key]!.getTotalAmount();
            total += value.getTotalAmount();
        }
        
        return total;
    }
    
    func purchaseProperty(propertyName:String, money:StackOfCurrency) {
        //Assignment -- Write purchase property method
        //return property card and currency
        
        
        
    }
    
    func addPropertyCard(propertyName:String, card:PropertyCard){
        propertyCards[propertyName] = card;
    }
    
    func addPropertyCard(card:PropertyCard){
        propertyCards[card.getId()] = card
    }
    
    private func getProperty(propertyName:String) -> PropertyCard{
        return propertyCards.removeValue(forKey: propertyName)!;
    }
    
    func setTray(trayOfMoney:[Int:StackOfCurrency]){
        self.trayOfMoney = trayOfMoney;
    }
    
}


class Property{
    var name:String;
    var numHouses:Int;
    var hotel:Int;
    
    init(name:String, hotel:Int, numHouses:Int) {
        self.hotel = hotel;
        self.name = name;
        self.numHouses = numHouses;
    }
    
    func getName() -> String {
        return name;
    }
    
    func addHouse() -> Bool {
        if (numHouses<4){
            numHouses = numHouses + 1;
            return true;
        }
        
        return false;
    }
    
    func removeHouse() -> Bool {
        if(numHouses>0){
            numHouses = numHouses - 1;
            return true;
        }
        
        return false;
    }
    
    func addHotel() -> Bool {
        if(hotel < 1){
            hotel = 1;
            return true;
        }
        
        return false;
    }
    
    
    func removeHotel() -> Bool {
        if(hotel > 0){
            hotel = 0;
            return true;
        }
        
        return false;
    }
    
    func getNumHouse() -> Int{
        return numHouses;
    }
    
    func getNumHotels() -> Int{
        return hotel;
    }
    
}

class Board{
    var board = [Property]();
    
    init(){
        
    }
    
    init(board:[Property]){
        self.board;
    }
    
    func setBoard(board:[Property]){
        self.board = board;
    }
    
    //move around board... 
    
}


class GameRunner{
    
    let bank = Bank()
    
    init(){
        self.loadCurrency();
        self.createPropertyCards();
        
    }
    
    
    func loadCurrency(){
        var tray = [Int:StackOfCurrency]()
        
        tray[1] = StackOfCurrency(stackCurrency: Array(repeating: Currency(value: 1, denomination: "One"), count: 10))
        tray[5] = StackOfCurrency(stackCurrency: Array(repeating: Currency(value: 5, denomination: "Five"), count: 10))
        tray[10] = StackOfCurrency(stackCurrency: Array(repeating: Currency(value: 10, denomination: "Ten"), count: 10))
        tray[20] = StackOfCurrency(stackCurrency: Array(repeating: Currency(value: 20, denomination: "Twenty"), count: 10))
        
        bank.setTray(trayOfMoney: tray)
    }
    
    func createPropertyCards(){
        bank.addPropertyCard(propertyName: "Boardwalk", card: PropertyCard(propertyName: "Boardwalk", rent: 10, rentOneHouse: 20, rentTwoHouse: 30, rentThreeHouse: 40, rentFourHouse: 50))
    
    }
    
    
    
}



