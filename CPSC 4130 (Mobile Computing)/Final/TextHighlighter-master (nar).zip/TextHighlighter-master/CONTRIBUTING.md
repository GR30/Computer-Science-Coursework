## How to contribute


1. Fork TextHighlighter
1. Check out the `develop` branch
1. Make a feature branch (use `git checkout -b "new-feature"`)
1. Make your new feature or bugfix on your branch
1. From your branch, make a pull request against `nakshay/TextHighlighter/develop`
1. Wait for your change to be pulled into `nakshay/TextHighlighter/develop`
1. Merge `nakshay/TextHighlighter/develop` into your origin `develop`
1. Delete your feature branch
