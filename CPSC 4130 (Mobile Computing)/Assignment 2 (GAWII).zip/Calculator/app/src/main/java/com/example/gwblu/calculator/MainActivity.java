package com.example.gwblu.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    boolean Addition, Subtract, Multiply, Divide;
    boolean operationSelected, DivByZero = false;
    float number1, number2, solution;
    String eq = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView inputDisplay = (TextView) findViewById(R.id.inputDisplay);
        final TextView equationDisplay = (TextView) findViewById(R.id.equationDisplay);

        Button zero = (Button) findViewById(R.id.button2);
        Button one = (Button) findViewById(R.id.button5);
        Button two = (Button) findViewById(R.id.button6);
        Button three = (Button) findViewById(R.id.button7);
        Button four = (Button) findViewById(R.id.button9);
        Button five = (Button) findViewById(R.id.button10);
        Button six = (Button) findViewById(R.id.button11);
        Button seven = (Button) findViewById(R.id.button13);
        Button eight = (Button) findViewById(R.id.button14);
        Button nine = (Button) findViewById(R.id.button15);

        Button equals = (Button) findViewById(R.id.button);
        Button decimal = (Button) findViewById(R.id.button3);
        Button add = (Button) findViewById(R.id.button12);
        Button subtract = (Button) findViewById(R.id.button16);
        Button multiply = (Button) findViewById(R.id.button8);
        Button divide = (Button) findViewById(R.id.button4);
        Button delete = (Button) findViewById(R.id.button17);
        Button clear = (Button) findViewById(R.id.button18);
        Button clearEquation = (Button) findViewById(R.id.button19);
        //Button negative = (Button) findViewById(R.id.button20);


        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (inputDisplay.getText() != "0" || inputDisplay.getText() == "Divide by 0 error"){
                    inputDisplay.setText(inputDisplay.getText() + "0");
                }
            }
        });
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                    inputDisplay.setText("1");
                }else{
                    inputDisplay.setText(inputDisplay.getText() + "1");
                }
            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                    inputDisplay.setText("2");
                }else{
                    inputDisplay.setText(inputDisplay.getText() + "2");
                }
            }
        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                    inputDisplay.setText("3");
                }else{
                    inputDisplay.setText(inputDisplay.getText() + "3");
                }
            }
        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                    inputDisplay.setText("4");
                }else{
                    inputDisplay.setText(inputDisplay.getText() + "4");
                }
            }
        });
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                    inputDisplay.setText("5");
                }else{
                    inputDisplay.setText(inputDisplay.getText() + "5");
                }
            }
        });
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                    inputDisplay.setText("6");
                }else{
                    inputDisplay.setText(inputDisplay.getText() + "6");
                }
            }
        });
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                    inputDisplay.setText("7");
                }else{
                    inputDisplay.setText(inputDisplay.getText() + "7");
                }
            }
        });
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                    inputDisplay.setText("8");
                }else{
                    inputDisplay.setText(inputDisplay.getText() + "8");
                }
            }
        });
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                    inputDisplay.setText("9");
                }else{
                    inputDisplay.setText(inputDisplay.getText() + "9");
                }
            }
        });
        decimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(inputDisplay.getText().toString().contains("."))) {
                    if (inputDisplay.getText() == "0" || inputDisplay.getText() == "Divide by 0 error") {
                        inputDisplay.setText("0.");
                    } else {
                        inputDisplay.setText(inputDisplay.getText() + ".");
                    }
                }
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                number1 = Float.parseFloat(inputDisplay.getText() + "");
                Addition = true;
                operationSelected = true;
                inputDisplay.setText("0");
                eq = number1 + " + ";
                equationDisplay.setText(eq);
            }
        });
        subtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                number1 = Float.parseFloat(inputDisplay.getText() + "");
                Subtract = true;
                operationSelected = true;
                inputDisplay.setText("0");
                eq = number1 + " - ";
                equationDisplay.setText(eq);
            }
        });
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                number1 = Float.parseFloat(inputDisplay.getText() + "");
                Multiply = true;
                operationSelected = true;
                inputDisplay.setText("0");
                eq = number1 + " * ";
                equationDisplay.setText(eq);
            }
        });
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                number1 = Float.parseFloat(inputDisplay.getText() + "");
                Divide = true;
                operationSelected = true;
                inputDisplay.setText("0");
                eq = number1 + " / ";
                equationDisplay.setText(eq);
            }
        });

        /*negative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){

                if (inputDisplay.getText() != "Divide by 0 error") {
                    if (operationSelected == false) {
                        number1 *= -1;
                        inputDisplay.setText(number1 + "");
                    } else {
                        number2 *= -1;
                        inputDisplay.setText(number2 + "");
                    }
                }
            }
        });*/

        equals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                number2 = Float.parseFloat(inputDisplay.getText() + "");

                if (Addition == true) {
                    solution = number1 + number2;
                    Addition = false;
                }

                if (Subtract == true) {
                    solution = number1 - number2;
                    Subtract = false;
                }

                if (Multiply == true) {
                    solution = number1 * number2;
                    Multiply = false;
                }

                if (Divide == true)
                {
                    if(number2 != 0.0)
                    {
                        solution = number1 / number2;
                    }
                    else
                    {
                        inputDisplay.setText("Divide by 0 error");
                        DivByZero = true;
                    }
                    Divide = false;
                }

                if ((solution == 0.0)&&(DivByZero == false)){ inputDisplay.setText("0"); }
                eq = "";
                equationDisplay.setText(null);
                operationSelected = false;
                DivByZero = false;
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                CharSequence inputDisplayText = inputDisplay.getText();
                inputDisplayText = inputDisplayText.subSequence(0, inputDisplayText.length() - 1);

                if (inputDisplayText.length() < 1) {
                    inputDisplay.setText("0");
                }else{
                    inputDisplay.setText(inputDisplayText);
                }
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                inputDisplay.setText("0");
            }
        });

        clearEquation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                inputDisplay.setText("0");
                equationDisplay.setText("");
                eq = "";
                Addition = false;
                Subtract = false;
                Multiply = false;
                Divide = false;
                operationSelected = false;
                number2 = 0;
                number1 = 0;
            }
        });
    }
}
