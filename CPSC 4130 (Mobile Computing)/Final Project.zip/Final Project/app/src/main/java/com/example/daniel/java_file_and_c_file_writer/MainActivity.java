package com.example.daniel.java_file_and_c_file_writer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button C;
    private Button Java;
    private Button Open;
    private Button Email;
    private Button test;
    private Button fileExplorerTest;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        C = findViewById(R.id.C);
        C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenCEditor();
            }
        });

        Java = findViewById(R.id.Java);
        Java.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenJavaEditor();
            }
        });

        Open = findViewById(R.id.Open);
        Open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenEmail();
            }
        });

        Email = findViewById(R.id.Email);
        Email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenFiles();
            }
        });



        fileExplorerTest = findViewById(R.id.FileExplorerTest);
        fileExplorerTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenFileExplorer();
            }
        });
    }

    public void OpenCEditor(){
        Intent I = new Intent(this, CActivity.class);
        startActivity(I);
    }
    public void OpenJavaEditor(){
        Intent J = new Intent(this, JavaActivity.class);
        startActivity(J);
    }
    public void OpenEmail()
    {
        Intent K = new Intent(this, EmailActivity.class);
        startActivity(K);
    }
    public void OpenFiles(){
        Intent L = new Intent(this, OpenActivity.class);
        startActivity(L);
    }

    public void OpenFileExplorer() {
        Intent N = new Intent(this, FileExplorerActivity.class);
        startActivity(N);
    }
}
