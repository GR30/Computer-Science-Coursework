package com.example.daniel.java_file_and_c_file_writer;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class CActivity extends AppCompatActivity {

    EditText text;
    Button button;

    final String[] Ckeywords={"auto","double","int","struct","const","float","short","unsigned","break","else","long","switch","continue","for","signed",
            "void","case","enum","register","typedef","default","goto","sizeof","volatile","char","extern","return","union","do","if","static",
            "while"};


    public static final String FILE_NAME = "mytext.c";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);

        text = findViewById(R.id.editTextC);
        button = findViewById(R.id.SendAsC);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchEmail();
            }
        });

        SyntaxTextWatcher watcher = new SyntaxTextWatcher();
        text.addTextChangedListener(watcher);
    }

    public void createFile(View view) {
        String txt = text.getText().toString();

        FileOutputStream outputStream = null;

        File file = new File(FILE_NAME);

        try {
            outputStream = openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            outputStream.write(txt.getBytes());
            Toast.makeText(this, "The code executes the write", Toast.LENGTH_SHORT).show();
            outputStream.close();

        }
        catch (IOException E)
        {
            E.printStackTrace();
            Toast.makeText(this, "the write failed", Toast.LENGTH_SHORT).show();
        }

    }

    public void launchEmail() {

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO,
                Uri.fromParts("mailto", "", null));
        emailIntent.putExtra(Intent.EXTRA_EMAIL, "");
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "");
        emailIntent.putExtra(Intent.EXTRA_TEXT, text.getText().toString());
        startActivityForResult(emailIntent, 1);
        Toast.makeText(this, "The Open intent Was executed", Toast.LENGTH_LONG).show();
    }
}
