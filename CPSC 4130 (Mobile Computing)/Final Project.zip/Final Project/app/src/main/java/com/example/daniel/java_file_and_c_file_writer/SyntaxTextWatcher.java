package com.example.daniel.java_file_and_c_file_writer;

import java.util.Vector;

import android.graphics.Color;
import android.text.Editable;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;


public class SyntaxTextWatcher implements TextWatcher, ColorableText {

    private Editable editText = null;
    private String prevText = "";
    private TextColorizer colorizer = new TextColorizer();


    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable editText) {
        this.editText = editText;
        String currText = editText.toString();
        if (this.prevText.equals(currText))
            return;
        else
            this.prevText = currText;

        ForegroundColorSpan[] toRemoveSpans = editText.getSpans(0, currText.length(), ForegroundColorSpan.class);
        for (int i = 0; i < toRemoveSpans.length; i++)
        {
            editText.removeSpan(toRemoveSpans[i]);
        }


        // Set the colorizer to work adding new spans
        colorizer.processText(this);


    }

    @Override
    public void setColor(int first, int length, int color) {
        if (this.editText == null)
            return;

        // check for illegal input and correct
        boolean valid = true;
        if (first < 0) {
            first = 0;
            valid = false;
        }
        if (length <= 0) {
            length = 1;
            valid = false;
        }

        int currLen = this.editText.toString().length();
        if (first + length > currLen) {
            length = currLen - first;
            valid = false;
        }

        // if illegal input was found, change the color to magenta
        if (!valid) {
            color = Color.MAGENTA;
        }

        editText.setSpan(new ForegroundColorSpan(color), first, first + length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);


    }

    @Override
    public String getText() {
        return this.editText.toString();
    }
}
