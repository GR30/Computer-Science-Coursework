package com.example.daniel.java_file_and_c_file_writer;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class OpenActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_file);
    }
}
