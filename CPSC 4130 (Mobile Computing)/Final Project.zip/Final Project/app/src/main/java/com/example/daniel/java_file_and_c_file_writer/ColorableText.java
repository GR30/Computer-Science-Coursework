package com.example.daniel.java_file_and_c_file_writer;

public interface ColorableText {
    public void setColor(int first, int length, int color);
    public String getText();
}
