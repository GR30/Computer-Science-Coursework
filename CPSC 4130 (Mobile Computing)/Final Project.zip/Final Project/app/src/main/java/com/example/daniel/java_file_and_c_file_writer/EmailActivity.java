package com.example.daniel.java_file_and_c_file_writer;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.Toast;

import org.apache.http.params.HttpParams;

public class EmailActivity extends AppCompatActivity {

    private String package_name = "com.google.android.gm";
    private String class_name = "com.google.android.gm.ComposeActivityGmail";
    private Button button;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);

        button = findViewById(R.id.toEmailButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                launchEmail();
                //testifwork();

                //Intent intent = getPackageManager().getLaunchIntentForPackage("com.google.android.gm");
                //startActivity(intent);
            }
        });


    }

   public void launchEmail() {

       Intent emailIntent = new Intent(Intent.ACTION_SENDTO,
               Uri.fromParts("mailto", "", null));
       emailIntent.putExtra(Intent.EXTRA_EMAIL, "");
       emailIntent.putExtra(Intent.EXTRA_SUBJECT, "");
       emailIntent.putExtra(Intent.EXTRA_TEXT, "This is the textView");
       startActivityForResult(emailIntent, 1);
       Toast.makeText(this, "The Open intent Was executed", Toast.LENGTH_LONG).show();
   }
}
