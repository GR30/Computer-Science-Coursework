package com.example.daniel.java_file_and_c_file_writer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.prefs.BackingStoreException;

public class JavaActivity extends AppCompatActivity {

    EditText code;
    Button button;
    public static final String FILE_NAME = "mytext.java";
    //TextHighlighter highlighter = new TextHighlighter();
    String[] colors = {"#fe0008", "#fe00fe", "#0011fe", "#00f6fe", "#00fe00", "#fafe00", "#fea500"};
    String newText;
    String text = "public static void main(String[] args){}";
    boolean settingText = true;
    boolean isHighlightingText = false;
    final static String[] theKeyWords ={"abstract","assert boolean","break","byte","case","catch","char","class",
            "const","continue","default","do","double","else","enum ","extends","final","finally","float",
            "for","goto","if","implements","import","instanceof","int","interface","long","native","new","package",
            "private","protected","public","return","short","static","strictfp"," super","switch","synchronized",
            "this","throw","throws","transient","try","void","volatile","while"};



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_java);

        code = findViewById(R.id.javaText);
        button = findViewById(R.id.openEmail);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchEmail();
            }
        });

        SyntaxTextWatcher watcher = new SyntaxTextWatcher();
        code.addTextChangedListener(watcher);
    }


/*        code.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                if (text.charAt(start) == '#') {

//                    SpannableString spannableString = new SpannableString(code.getText().toString());
//                    ForegroundColorSpan foregroundSpan = new ForegroundColorSpan(ContextCompat.getColor(getApplicationContext(), R.color.highlightColor));
//                    spannableString.setSpan(foregroundSpan, start,
//                            spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
//                    code.setText(spannableString);

//                }


            }

            @Override
            public void afterTextChanged(Editable s) {
               *//* if (isHighlightingText == false) {
                    isHighlightingText = true;
                    highlightText(code, s.toString());
                } else {
                   isHighlightingText = false;
                }*//*

                *//*ForegroundColorSpan foregroundColorSpan = new ForegroundColorSpan(Color.RED);
                String s1 = s.toString();
                String txt = code.getText().toString();
                int i = 0;

                for (int j = 0; j < theKeyWords.length; j++)
                {
                    String compar = theKeyWords[j];
                    while ((i = s1.indexOf(txt, i)) >= 0){
                        if(txt.substring(i, i + txt.length()) == compar){
                            s.setSpan(foregroundColorSpan, i, i + txt.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                        i += txt.length();*//*


                    }
                }

            }
        });
    }*/

/*    public void highlightText(EditText code, String searchString){
        //SpannableString string = new SpannableString("Text with a foreground color span");
        //string.setSpan(new ForegroundColorSpan(greenColorValue), 12, 28, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        String s = code.getText().toString();
        SpannableString str = new SpannableString(s);

        //find an iterateion
        if(searchString != null && !searchString.equalsIgnoreCase("")){
            int startIndex = 0;
            while (true){
                startIndex = s.indexOf(searchString, startIndex);

                if(startIndex >= 0 && Arrays.asList(theKeyWords).contains(searchString)) {
                    str.setSpan(new BackgroundColorSpan(Color.YELLOW),
                            startIndex, startIndex + searchString.length(),
                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    startIndex++;
                }else {
                    break;
                }
            }
        }
        code.setText(str);
        //code.getText().toString();
        code.setSelection(code.getText().toString().length());

    }*/

    public void createFile(View view) {
        String txt = code.getText().toString();
        FileOutputStream outputStream = null;
        File file = new File(FILE_NAME);
        try {
            outputStream = openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            outputStream.write(txt.getBytes());
            Toast.makeText(this, "The code executes the write", Toast.LENGTH_SHORT).show();
            outputStream.close();

        }
        catch (IOException E)
        {
            E.printStackTrace();
            Toast.makeText(this, "the write failed", Toast.LENGTH_SHORT).show();
        }

    }

    public void launchEmail() {

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO,
                Uri.fromParts("mailto", "", null));
        emailIntent.putExtra(Intent.EXTRA_EMAIL, "");
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "");
        emailIntent.putExtra(Intent.EXTRA_TEXT, code.getText().toString());
        startActivityForResult(emailIntent, 1);
        Toast.makeText(this, "The Open intent Was executed", Toast.LENGTH_LONG).show();
    }

}
