package com.example.daniel.java_file_and_c_file_writer;

import java.util.HashSet;
import java.util.Set;
import android.graphics.Color;
import android.util.Log;

public class TextColorizer extends JavaActivity {

    Set<String> theKeyWordsHashSet = new HashSet<String>();
    int startComment;
    int endComment;
    int lengthWord;
    int startComment2;
    int endComment2;
    int lengthWord2;
    int startWord;
    int endWord;
    int wordLength;

    public TextColorizer(){
        for(int i = 0; i < theKeyWords.length; i++){
            theKeyWordsHashSet.add(theKeyWords[i]);
        }
    }

    public void processText(ColorableText colorableObject){
        String theText = colorableObject.getText();
        int length = theText.length();
        colorableObject.setColor(0, length, Color.BLACK);
        theText = " " + theText + " ";
        for (String rWord : theKeyWordsHashSet) {
            startWord = 0;
            endWord = 0;
            wordLength = 0;
            while (startWord >= 0) {
                startWord = theText.indexOf(rWord, startWord + 1);
                wordLength = rWord.length();
                endWord = wordLength + startWord;
                if (!(startWord < 0 || startWord > theText.length())) {
                    Log.i("word s", Integer.toString(startWord));
                    Log.i("word e", Integer.toString(endWord));
                    if (!(theText.substring(startWord - 1, endWord + 1).trim()
                            .length() > wordLength)) {
                        colorableObject.setColor(startWord - 1, wordLength,
                                Color.RED);
                    }
                }
            }
        }
        startComment = 0;
        endComment = 0;
        lengthWord = 0;
        while (startComment >= 0) {
            startComment = theText.indexOf("//", startComment + 1);
            if (startComment != -1) {
                for (int a = startComment; a < theText.length(); a++) {
                    endComment = a + 1;
                    Log.i("startComment", Integer.toString(startComment));
                    Log.i("endComment", Integer.toString(endComment));
                    String test = theText.substring(startComment + 1,
                            endComment);
                    if (!(test.contains("\n"))) {
                        // get word length
                        lengthWord = endComment - startComment;
                        // log length
                        Log.i("commentLength", Integer.toString(lengthWord));

                        if ((lengthWord + endComment) > (theText.length() + 1)) {
                            lengthWord = theText.length() - startComment - 1;
                            colorableObject.setColor(startComment - 1,
                                    lengthWord, Color.BLUE);
                        } else {
                            colorableObject.setColor(startComment - 1,
                                    lengthWord, Color.BLUE);
                        }
                    }
                }
            }
        }

        startComment2 = 0;
        endComment2 = 0;
        lengthWord2 = 0;
        while (startComment2 >= 0) {
            startComment2 = theText.indexOf("/*", startComment2 + 1);
            if (startComment2 != -1) {
                for (int a = startComment2; a < theText.length(); a++) {
                    endComment2 = a + 1;
                    Log.i("startComment2", Integer.toString(startComment2));
                    Log.i("endComment2", Integer.toString(endComment2));
                    String test = theText.substring(startComment2 + 1,
                            endComment2);
                    if (!(test.contains("*/"))) {

                        lengthWord2 = endComment2 - startComment2;
                        Log.i("commentLength2", Integer.toString(lengthWord2));
                        colorableObject.setColor(startComment2 - 1,
                                lengthWord2 + 1, Color.BLUE);
                    }
                }
            }
        }

    }


}
